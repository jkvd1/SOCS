#include <stdio.h>
#include <stdlib.h>
int main(){
		char *str;
		str = (char*)malloc(1000005 * sizeof(char));
		
		scanf("%[^\n]", str); 
		
		int a[26], ctr = 0;
		for(int j = 0; j < 26; j++) a[j] = 0;
		
		for(int j = 0; str[j] != '\0'; j++){
			a[str[j] - 'a'] = 1;
		}
		
		int v = 0, c = 0;
		for(int i = 0; i < 26; i++){
			if(a[i]){
				if(i == 'a' - 'a' ||
					i == 'u' - 'a'||
					i == 'i' - 'a' ||
					i == 'e' - 'a' ||
					i == 'o' - 'a'){
					v++;
				}else{
					c++;
				}
			}
		}
		
		printf("Vocal: %d\n", v);
		printf("Consonant: %d\n", c);
	
    
    return 0;
}
