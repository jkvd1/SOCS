#include <stdio.h>

int main(){
	
	int m,n;
	scanf("%d %d", &m, &n);
	
	while(m--){
		for(int i = 0 ; i < n; i++){
			
			for(int j = 0; j < n-i-1; j++){
				printf(" ");
			}
			for(int j = 0; j < i+1; j++){
				printf("*");
			}
			printf("\n");
		}
	}

    
    return 0;
}
