#include <stdio.h>

void swap(int* xp, int* yp){
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

int main(){
	
	int n;
	scanf("%d", &n);
	
	int arr[n];
	int idx[n];
	for(int  i = 0; i < n; i++){
		scanf("%d", &idx[i]);
	}
	for(int  i = 0; i < n; i++){
		scanf("%d", &arr[i]);
	}
	
	for(int i = 0; i < n; i++)
		for(int j = 0; j < n - i - 1; j++)
       		if(idx[j] > idx[j + 1]){
            	swap(&arr[j], &arr[j + 1]);
            	swap(&idx[j], &idx[j + 1]);
            }
                
	for(int  i = 0; i < n; i++){
		printf("%d", arr[i]);
		if(i!=n-1) printf(" ");
		else printf("\n");
	}
    
    return 0;
}
