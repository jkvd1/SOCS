#include <stdio.h>

int main(){
	int tc;
	scanf("%d", &tc); 
	for(int i = 1; i <= tc; i++){
		int n, m;
		scanf("%d %d", &n, &m);
		int ans = 0, multi = 1, bit;
	    while(n || m){
	        bit= (n%10)+ (m%10);
	        bit %= 10;
	        ans = (bit * multi) + ans;
	        multi*=10;
	        n /= 10;
	        m /= 10;
	    }
	    printf("Case #%d: %d\n", i, ans);
	}
    
    return 0;
}
