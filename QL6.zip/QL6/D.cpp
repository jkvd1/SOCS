#include <stdio.h>

int main(){
	int tc;
	scanf("%d", &tc); 
	for(int i = 1; i <= tc; i++){
		int n;
		scanf("%d", &n);
		int maxi = -100000001;
		int maxj = -100000001;
		
		for(int j = 0; j < n; j++){
			int v;
			scanf("%d", &v);
			if(v > maxi){
				int temp = maxi;
				maxj = maxi;
				maxi = v;			
			}else if(v > maxj){
				maxj = v;
			}
		}
		printf("Case #%d: %d\n",i, maxi+maxj);
	}
    
    return 0;
}
