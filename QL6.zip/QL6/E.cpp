#include <stdio.h>
#include <stdlib.h>
int main(){
	int tc;
	scanf("%d", &tc);  getchar();
	for(int i = 1; i <= tc; i++){
		char *str;
		str = (char*)malloc(100005 * sizeof(char));
		
		scanf("%s", str); getchar();
		
		int a[26], ctr = 0;
		for(int j = 0; j < 26; j++) a[j] = 0;
		
		for(int j = 0; str[j] != '\0'; j++){
			if(a[str[j] - 'a'] == 0) ctr++;  
			a[str[j] - 'a'] = 1;
		}
		
		
		printf("Case #%d: ", i);
		if(ctr%2==0) printf("Breakable\n");
		else printf("Unbreakable\n");
	}
    
    return 0;
}
